## Read nImages and Convert to Text using PHP
Pretty basic implementation and no effort has been put to achieve optimum results. I will consider this work in progress for now. you can view tutorial here https://www.youtube.com/watch?v=9dT_g4nBmvM&ab_channel=CodeWithBen
