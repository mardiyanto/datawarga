<?php
$servername = "localhost";
$username = "u1732927_sukait";
$password = "m4rd1best";
$database = "u1732927_laras"; // Ganti dengan nama database Anda

$conn = mysqli_connect($servername, $username, $password, $database);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
